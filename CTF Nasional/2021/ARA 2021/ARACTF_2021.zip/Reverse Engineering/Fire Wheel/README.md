# Fire Wheel [500 pts]

**Category:** Reverse Engineering
**Solves:** 0

## Description
>"Pendekar pedang itu melompat ke belakang lawan dan berputar di udara sambil melepaskan serangan api dalam gerakan melingkar."

Kalian akan mendapatkan flag jika kalian mampu menemukan key yang tepat untuk melewati validasi!

 *author : kosong*

[https://drive.google.com/file/d/1P2xfaH8xKkkkfGc41b73fH012Kt1RGTX/view?usp=sharing](https://drive.google.com/file/d/1P2xfaH8xKkkkfGc41b73fH012Kt1RGTX/view?usp=sharing)

**Hint**
* Objdump

## Solution

### Flag

