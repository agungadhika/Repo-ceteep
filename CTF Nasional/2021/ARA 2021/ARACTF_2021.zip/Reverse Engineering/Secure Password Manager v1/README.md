# Secure Password Manager v1 [500 pts]

**Category:** Reverse Engineering
**Solves:** 0

## Description
>Waduh program untuk mengembalikan passwordku corrupt dan sekarang hanya hanya tersisa program untuk merahasiakan passwordku saja :( . Dapatkah kalian membantuku mengembalikan password akun moontoon ku supaya aku bisa bermain mobile legend lagi ? 

Secured password : e4 ff 9b c8 25 92 55  0 d4 85 6c ca  6 9b 4e  b

 *author : kosong*
 
 Flag : ara2021{password}

[https://drive.google.com/file/d/1xU6nalKz0DiexZf2nbX6R8E5HBp78-s3/view?usp=sharing](https://drive.google.com/file/d/1xU6nalKz0DiexZf2nbX6R8E5HBp78-s3/view?usp=sharing)

**Hint**
* key 1 <= 100.
z3 will help with the rest

## Solution

### Flag

