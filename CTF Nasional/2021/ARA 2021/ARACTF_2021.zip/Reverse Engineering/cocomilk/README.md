# cocomilk [342 pts]

**Category:** Reverse Engineering
**Solves:** 23

## Description
>Qiqi adalah seorang zombie yang sering pelupa. Suatu hari ia membuat kodingan dalam bahasa C++ untuk membuat kode rahasia lokasi cocomilk. Namun beberapa saat kemudian dia lupa menulis kodingan tersebut dalam bahasa C++ dan menuliskannya dalam bahasa Python. Qiqi yang kebingungan mencoba menginputkan lokasi cocomilk tersebut dengan menjalankan kodingannya dalam bahasa C++ dan Python. Anehnya, kodingannya dapat berjalan dan menghasilkan Output 1 pada bahasa C++ dan Output 2 pada bahasa Python. Beberapa saat kemudian, Qiqi melupakan lokasi rahasia cocomilk yang barusan diinputkan. Bantu Qiqi untuk mendapatkan lokasi rahasia cocomilk miliknya!

*author : Dz*

[https://drive.google.com/file/d/1ac8nqKzrDFluw3SSpGN4g6A7OV4e3_4c/view?usp=sharing](https://drive.google.com/file/d/1ac8nqKzrDFluw3SSpGN4g6A7OV4e3_4c/view?usp=sharing)

**Hint**
* -

## Solution

### Flag

