# Feedback [50 pts]

**Category:** Feedback
**Solves:** 27

## Description
>Halo Sobat ARA kami dari pihak panitia meminta Feedback kalian terhadap penyelenggaraan ARA 2021 kali ini. Terima kasih sobat ARA. 

https://intip.in/FeedbackCTFARA

**Hint**
* -

## Solution

### Flag

