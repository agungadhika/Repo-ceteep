# 0zip [101 pts]

**Category:** Misc
**Solves:** 36

## Description
>PT Pama Persada sedang melakukan pengeboran untuk mendapatkan mineral di lokasi penemuan mineral terbaru mereka.
seorang engginer nya lalu berkata : We need to go deeper...

*author : IA*

[https://drive.google.com/file/d/1qgbFNX4oLVQzScgbPHtKFStMr1UOZzHf/view?usp=sharing](https://drive.google.com/file/d/1qgbFNX4oLVQzScgbPHtKFStMr1UOZzHf/view?usp=sharing)

**Hint**
* -

## Solution

### Flag

