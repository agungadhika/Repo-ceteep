# We Promise No shit! [280 pts]

**Category:** Misc
**Solves:** 26

## Description
>PT Pama Persada sedang membuat sayembara untuk memecahkan teka-teki yang mereka buat, cari tau siapa aku dan dia maka kamu akan menemukan harta karunya!

Aku merupakan website yang mulai viral pada tahun 2015, diciptakan oleh salah satu alumni dari kampus penyelenggara ARA CTF ini. Beritaku di upload di kanal its pada tanggal 11 januari 2016 aku senang sekali waktu itu.

Dia adalah judul lagu yang dinyanyikan oleh salah satu diva di Indonesia, dan mungkin keluargamu sering mendengarkannya di tv, kadang bercerita tentang karma.

Coba ketik ini di halamannya mbahmu yang terkenal itu :
aku/dia

Mungkin lebih sopan untuk nulisnya huruf kecil semua

*author : lambangaw*

format flag : ara2021{}

**Hint**
* -

## Solution

### Flag

