# Gordon [500 pts]

**Category:** Misc
**Solves:** 2

## Description
>"Omong-omong soal mentah, gue lagi ngotak-atik SD Card yang tadi jatuh di jalan, gue liat tadi RATA dong di jalan, terus nemu file ini. Gue ga bisa baca sih, tapi ya kayanya isinya menarik."
"Mas, ini warteg"

*author : spitfire*
![warteg.jpg](/files/134b13efd5fe3dab9d69462fcdbfa965/warteg.jpg)

[https://drive.google.com/drive/folders/1W1v93rQ-Kz87CxN5eOeVePtqJoLhlWZJ?usp=sharing](https://drive.google.com/drive/folders/1W1v93rQ-Kz87CxN5eOeVePtqJoLhlWZJ?usp=sharing)

**Hint**
* Datanya bisa dibagi 3, kan? Foto wartegnya kayanya penting itu.
* RGB

## Solution

### Flag

