# Big Dict [417 pts]

**Category:** Cryptography
**Solves:** 16

## Description
>Ndak bisa bahasa enggres?

XWZYYXWXYZXWZYYXYXYZXYXYWXYXYZXYXYYXWXXXXWXYXXYXYXXWXYXXWXWYXWZYYXWZXYXWYZXXWZWWXYXYXXWZZZXWZWXXWZYYXWZZZXWYZXXWZXXXWZYZXWZYZXWZXYXWXZY

*author : nodoge*

[https://drive.google.com/file/d/10wb8JcsnuNOtpk4Mgb8UaYPa44vsw_hU/view?usp=sharing](https://drive.google.com/file/d/10wb8JcsnuNOtpk4Mgb8UaYPa44vsw_hU/view?usp=sharing)

**Hint**
* -

## Solution

### Flag

