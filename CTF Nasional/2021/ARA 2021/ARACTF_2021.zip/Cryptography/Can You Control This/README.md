# Can You Control This [500 pts]

**Category:** Cryptography
**Solves:** 2

## Description
>Seseorang berkata kepada saya mengenai kontrol dan cek , namun saya tidak paham apa yang dimaksud orang itu hmmm.
NB : Flag terbagi menjadi 2 bagian

*author : kosong*

[nc 149.28.157.74 1024](https://)

[https://drive.google.com/file/d/1diT3mgtDonIptdi25rdSpwuPsMG9cqmk/view?usp=sharing](https://drive.google.com/file/d/1diT3mgtDonIptdi25rdSpwuPsMG9cqmk/view?usp=sharing)

**Hint**
* -

## Solution

### Flag

