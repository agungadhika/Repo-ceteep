# Kode Rahasia [500 pts]

**Category:** Cryptography
**Solves:** 2

## Description
>Kamu adalah seseorang yang bekerja di PT Pama Persada.  Ditengah-tengah pekerjaan mu, seseorang teman datang dan berkata bahwa dia menemukan harta karun di salah satu lokasi penambangan. Tetapi dia tidak bisa memberitahukan lokasinya secara langsung, lalu berkata

"There is geometry in the humming of the strings, there is music in the spacing of the spheres. and at the end, you will find hamming is very useful"

dan memberikan sebuah lokasi titik koordinat

1001111001000111100100011000001110111101101100000011000111100101011000001110101

carilah lokasi dari harta karun tersebut

*author : BBCA*

**Hint**
* -

## Solution

### Flag

