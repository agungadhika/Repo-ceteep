# Dewan Kunci [100 pts]

**Category:** Cryptography
**Solves:** 38

## Description
>Lihat jari jemari anda

Cipher : zeq3p1z}nr5[xL;\sq2/7wjr7\irf,hrg.jr7w;[dedr;r8p60x6e{

*author : IA*

**Hint**
* -

## Solution

### Flag

