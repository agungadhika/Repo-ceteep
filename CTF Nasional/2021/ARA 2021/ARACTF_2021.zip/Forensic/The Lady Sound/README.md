# The Lady Sound [226 pts]

**Category:** Forensic
**Solves:** 29

## Description
>Pada suatu hari PT. Pama mendapatkan sebuah voice note yang sudah dirusak. Bantulah PT. Pama untuk memperbaiki file audio yang telah dirusak ini

*author : danev*

format flag : ara2021{} (dalam huruf kecil)

[https://drive.google.com/file/d/1qEWYxgvSnArG7jgL1iEJGSsmDO23GRBz/view?usp=sharing](https://drive.google.com/file/d/1qEWYxgvSnArG7jgL1iEJGSsmDO23GRBz/view?usp=sharing)

**Hint**
* -

## Solution

### Flag

