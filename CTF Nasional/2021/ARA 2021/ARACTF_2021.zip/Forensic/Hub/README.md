# Hub [474 pts]

**Category:** Forensic
**Solves:** 10

## Description
>Seorang tersangka kejahatan digital suka memindahkan file sensitif dengan cara tradisional. Dengan cara yang tentu saja legal, kami berhasil mendapatkan rekam aktivitas pada komputernya pada sebuah transaksi data. Namun karena banyaknya hal yang dipasang pada komputernya, kami sedikit kesulitan mendapatkan informasi tentang file tersebut. Bisakah kalian menemukan apa yang dia sembunyikan?

*author : spitfire*

[https://drive.google.com/file/d/19JesgOKbkTOsr3bIRG7DoQeotr9nWkMh/view?usp=sharing](https://drive.google.com/file/d/19JesgOKbkTOsr3bIRG7DoQeotr9nWkMh/view?usp=sharing)

**Hint**
* -

## Solution

### Flag

