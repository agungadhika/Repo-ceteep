# Jack Sparrow [427 pts]

**Category:** Forensic
**Solves:** 16

## Description
>Not all treasure is silver and gold mate! let the ship flow from left to right

*author : Christian Andrew*

[https://drive.google.com/file/d/1UrhBRJ75Db_X6L5g5mh9yTLeFP5qcJ28/view?usp=sharing](https://drive.google.com/file/d/1UrhBRJ75Db_X6L5g5mh9yTLeFP5qcJ28/view?usp=sharing)

**Hint**
* -

## Solution

### Flag

