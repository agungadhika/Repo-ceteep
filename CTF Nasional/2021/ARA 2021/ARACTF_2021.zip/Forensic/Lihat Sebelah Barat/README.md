# Lihat Sebelah Barat [498 pts]

**Category:** Forensic
**Solves:** 3

## Description
>~Sekilas Info!! Tahukah kamu? Sebagai salah satu kontraktor penambangan batubara terbesar di dunia, PT Pama Persada memiliki kompetensi yang luas & pemahaman mendalam dalam hal pengembangan & operasi tambang batubara yang meliputi : Eksplorasi, perencanaan, persiapan infrastruktur, operasi penambangan, reklamasi dan re-vegetasi di area bekas tambang ~

*author : BBCA*

[https://drive.google.com/file/d/1cEsTsHwMHzCZYloJQ4ox2JSj-rl2ZvIg/view?usp=sharing](https://drive.google.com/file/d/1cEsTsHwMHzCZYloJQ4ox2JSj-rl2ZvIg/view?usp=sharing)

**Hint**
* Sometimes the title and the image can give you a clue about what to do
* Sometimes important stuff is hidden in the metadata of the image or the file

## Solution

### Flag

